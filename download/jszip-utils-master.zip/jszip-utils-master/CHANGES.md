# v0.0.2 2014-05-19
- Drop the code for xhr on `file://` and fix an issue with `file://` to `http://` requests, see [#3](https://github.com/Stuk/jszip-utils/pull/3).

# v0.0.1 2014-04-27
 - First release.

